<?php
require __DIR__ . '/../../Frontend/Templates/layout.php';