<h2>Ajouter une étiquette</h2>

<?php require '_form.php';
