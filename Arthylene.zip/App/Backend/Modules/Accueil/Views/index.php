<h2>Consultation</h2>
<ul>
    <a href="/admin/produit.html">Liste des produits</a>
</ul>
<ul>
    <a href="/admin/label.html">Liste des etiquettes</a>
</ul>
<ul>
    <a href="/admin/checklist.html">Checklist</a>
</ul>
</br>
