<h2>Modifier une fiche</h2>

<?php require '_form.php';