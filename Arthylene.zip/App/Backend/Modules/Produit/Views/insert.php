<h2>Ajouter un produit</h2>

<?php require '_form.php';
